@include('template.frontend.header')
@yield('content')
@include('template.frontend.footer')